const Joi = require('joi');

const userValidator = Joi.object({
    name: Joi.string().required(),
    password: Joi.string().required(),
    email: Joi.string().email().required(),
    dob: Joi.string().required(),
    userType: Joi.string().optional(),
    gender: Joi.string().optional(),
})

module.exports = {  userValidator }

