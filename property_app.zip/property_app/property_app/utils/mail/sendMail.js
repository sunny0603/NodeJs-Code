
let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    service : 'Gmail',
    
    auth: {
      user: 'sunnykushwaha07@gmail.com',
      pass: 'Ragni@1996',
    }
    
});
