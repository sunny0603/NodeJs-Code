const mongoose = require('mongoose');

/// DB Connectivity

const init = ()=>{
    mongoose
        .connect("mongodb://localhost:27017/PropertyApp", {
            // useNewUrlParser: true,
            // useUnifiedTopology: true,
            // useFindAndModify: false,
            // useCreateIndex: true,
            // useNewUrlParser: true,
        })
        .then(() => {
            console.log(`DB Connected Successfully.`);
        })
        .catch((err) => {
            console.log(`DB Connectivity Failed !`, err);
        });
}

module.exports = {init};

