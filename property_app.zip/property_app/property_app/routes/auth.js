const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const  { ErrorCodes } =  require('../utils/response-codes/codes');


router.post('/registerUser', authController.registerUser);
router.post('/sendMail',authController.sendMail)


router.post('/sendOTP', authController.sendOTP);


module.exports = router