const express = require('express');
const createError = require('http-errors');
const router = express.Router();
const userRouter = require('./users');
const authRouter = require('./auth');
/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  res.send('Property_App Server is working...')
});

/// Auth Routes
router.use('/auth', authRouter)

// User Routes
router.use('/users' , userRouter)

// catch 404 and forward to error handler
router.use(function (req, res, next) {
  next(createError(404));
});

// error handler
router.use(function (err, req, res, next) {
  // set locals, only providing error in development
  console.log("Error Occured", err.message);
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};
  res.status(err.status || 500);
  res.json({ status: false, code: err.statusCode, message: err.message });
});


module.exports = router;
