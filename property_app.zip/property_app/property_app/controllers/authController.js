const createError = require('http-errors');
const { ResponseCodes } = require('../utils/response-codes/codes');
const { userValidator } = require('../utils/validation/userValidation');
const UserModel = require('../models/userModel');
const bcrypt = require('bcrypt');
const mongodb = require('mongodb');
const responseHandler = require('../utils/responseHandler');

const generateOTP = () => {
    return Math.floor(1000 + Math.random() * 9000);
};

exports.registerUser = async (req, res, next) => {

    try {

        // Validation
        const value = await userValidator.validate({ ...req.body });

        if (value.error) {
            let errMsg = [];
            value.error.details.forEach(ele => {
                errMsg.push(ele.message)
            })
            return next(createError(ResponseCodes.BAD_REQUEST, errMsg.join(',')))
        }

        // Check if user is already existed
        const users = await UserModel.find({ email: req.body.email });
        if (users.length > 0) {
            return next(createError(ResponseCodes.BAD_REQUEST, "Email is taken, Try different."))
        }

        req.body.isVerified = false;

        // Assign new Family Id
        req.body.familyId = new mongodb.ObjectId();

        // encrypt password
        req.body.password = await bcrypt.hashSync(req.body.password, 10);

        // create instance
        const userInstance = new UserModel(req.body);

        // save instance
        const result = await userInstance.save();

        console.log(result);

        return responseHandler(res, true, ResponseCodes.SUCCESS, "User registered successfully", {})



    } catch (error) {
        console.log(error);
        return next(createError(ResponseCodes.INTERNAL_SERVER_ERROR, error.message))

    }


    // next(createError(400 , 'Bad Request'))
}

exports.sendOTP = async (req, res, next) => {
    try {
        const email = req.body.email;

        if (!email) {
            return next(createError(ResponseCodes.BAD_REQUEST, "Email is required !"))
        }

        const result = await UserModel.findOne({ email: email }).lean();
        if (!result) {
            return next(createError(ResponseCodes.NOT_FOUND, "User not found !"))
        }

         // Generate otp
        const otp = generateOTP();
        const otpExpire =  String(Date.now() + 1000 * 60 * 10);
        UserModel.updateOne({ _id: result._id} , { otp : otp })


         // set otp expire

    } catch (error) {

    }

}
exports.sendMail=async(email,otp)=>{
    var mailOptions = {
        to: email,
        subject: "Otp for registration is: ",
        html: "<h3>OTP for account verification is </h3>" + "<h1 style='font-weight:bold;'>" + otp + "</h1>" // html body
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log('Message sent: %s', info.messageId);
        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
     
    });

};



