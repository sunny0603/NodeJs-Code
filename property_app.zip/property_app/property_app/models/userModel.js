const mongoose = require('mongoose');
const Schema =  mongoose.Schema;


const UserSchema = new Schema({
    name :{
        type:String,
    },
    dob:{
        type:String
    },
    age:{
        type:String
    },
    gender: {
        type: String
    },
    email: {
        type: String
    },
    userType: {
        type: String
    },
    familyId: {
        type: mongoose.Types.ObjectId
    },
    otp: {
        type: String
    },
    isVerified:{
        type: Boolean
    },
    otpExpire: {
        type: String
    },
    password:{
        type: String
    }
})

module.exports = mongoose.model('User', UserSchema)
