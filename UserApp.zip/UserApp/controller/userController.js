const createError = require('http-errors');
const { ResponseCodes } = require('../utils/response-codes/codes');
const { userValidator } = require('../utils/validation/userValidation');
const UserModel= require('../models/userModel');
const bcrypt = require('bcrypt');  
const jwt = require("jsonwebtoken")                                                                                  
const responseHandler = require('../utils/responseHandler');
const mailer=require('../utils/mail/sendMail');
const {responseMessage}=require('../utils/validation/responseMessage')

const generateOTP = () => {
  return Math.floor(1000 + Math.random() * 7000);
};


exports.registerUser =  async(req, res) => {
   console.log('12',req.body);

    try {
      
      const users = await UserModel.find({ email: req.body.email });
      if (users.length > 0) {
        
        return res.json({status:false,message:"Email is already used "});
      }
  
      req.body.isVerified = false;

      //req.body.password = await bcrypt.hashSync(req.body.password, 10);

      const userInstance = new UserModel(req.body);
      const result = await userInstance.save();

  
      //next();
      return responseHandler(res, true, ResponseCodes.SUCCESS, "User registered successfully", {})
  
  
  
    } catch (error) {
      console.log(error);
      return res.json({status:false,message:"Internal server error"});
  
    }
  } 

exports.reSendOTP = async (req, res, next) => {
    console.log("otp",req.body)
    try {
      const email = req.body.email;
  
      if (!email) {
        return res.json({status:false,message:"Email is required !"})
      }
  
      const result = await UserModel.findOne({ email: email });
      if (!result) {
        return res.json({status:false,message:"USer Not Found"})
       
      }
  
      const otp = generateOTP();
      const otpExpire = new Date().getTime();
      console.log('send otp, otp expire time',otpExpire);
      await UserModel.updateOne({ _id: result._id }, { otp: otp, otpExpire: otpExpire })
      var mailOptions = {
        to: email,
        subject: "Otp for registration is: ",
        html: "<h3>OTP for account verification is </h3>" + "<h1 style='font-weight:bold;'>" + otp + "</h1>"

      };
  
      mailer.sendMail(mailOptions,next);
      return res.json({status:true,message:"OTP has been send on your register email"})
    
    } catch (error) {
      console.log("Error", error);
      return res.json({status:false,message:"Internal server error"});
    }
  
  }
  exports.verifyOTP = async (req, res, next) => {
    try {
      console.log("verifyOTP", req.body)
  
      const emailId = req.body.email
  
      const userData = await UserModel.findOne({ email: emailId });
      const otp = userData.otp;
      console.log("backend", typeof otp);
      const expiredTime = Number(userData.otpExpire);
      const currentTime = new Date().getTime();
      console.log("userData------->", userData)
      console.log('otp----->', typeof req.body.otp)
      console.log("fsdaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",currentTime - expiredTime); 
      if(userData.isVerified==true){
        res.json({status:false,message:"User  is already verify"})
      }     
      if (req.body.otp == otp) {
        console.log("otp expire time", userData.otpExpire)
        const diff = 1000 * 60 * 1;
        console.log(expiredTime, currentTime, currentTime - expiredTime, diff);
        if ((currentTime - expiredTime)>diff) {
          return res.json({status:false,message:"OTP is expired"})
        }
        
      } else {
          return res.json({status:false,message:"Invalid OTP !"})
    
      }
      
      await UserModel.updateOne({ email: userData.email }, { isVerified: true, otpExpire: "", otp: '' });
      
      return res.json({status:true,message:"otp verified successfully"});
     
    } catch (error) {
      console.log("Error", error);
      return res.json({status:false,message:"Internal server error"});
      
  
    }
  
  
  }
  
  
exports.login = async (req, res, next) => {
  console.log("6", req.body)
  try {

    console.log("Inside try block")
    // const data = req.body
    const users = await UserModel.findOne({ email: req.body.email }).lean();
    console.log("users ", users)
    if(users.isVerified==true){
    if (!users) {
     
      return res.json({status:false,message:"pls enter registered email !"});
    }
    else {
      console.log("Inside else block", users)

      const password = await bcrypt.compareSync(req.body.password, users.password);

      if (!password) {
        
        return res.json({status:false,message:"please fill valid password !"});
      }

      console.log("password", password);
         
      var token = jwt.sign({
        _id: users._id,
        email: users.email
      }, process.env.JWTKEY);
    

      delete users.password;
      delete users.otp;
      delete users.otpExpire;

      console.log("jwt decoded token", jwt.decode(token))
      return res.json({ success: true, token: token })
    }}else{
      return res.json({status:false,message:"User is not verify,please first verify"})
    }

  } catch (error) {
    console.log(error)

  }
}