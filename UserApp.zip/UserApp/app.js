const express = require('express');
//const path = require('path');
require('./database/databaseConnection');
const app = express();
const userRouter=require('./route/userRoute')

app.use(express.json());
app.use(express.urlencoded({ extended: false }));


//app.use(express.static(path.join(__dirname, 'public')));
app.listen(4000,()=>{
    console.log(`server is running on port :${4000}`)
})
 app.use('/api/v1/', userRouter);

module.exports = app;


