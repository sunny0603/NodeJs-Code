const mongoose = require('mongoose');
const bcrypt = require('bcrypt');  
const userController=require('../controller/userController')
const mailer=require('../utils/mail/sendMail');
const db=require('../database/databaseConnection')
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    
    name: {
        type: String,
    },
    phone: {
        type: String
    },
    email: {
        type: String
    },
    
    otp: {
        type: String
    },
    isVerified: {
        type: Boolean
    },
    otpExpire: {
        type: String
    },
    password: {
        type: String
    }
   
    
})

UserSchema.pre('save',function(next){
    let user=this
    if(!user.isModified('password'&&!user.password)){
        next();
    }
    bcrypt.genSalt(10,function(error,salt){
        bcrypt.hash(user.password,salt,function(error,hash){
            user.password=hash;
            next();

        });
    });
})

UserSchema.post('save',async function(req,res){
    let user=this

console.log("---------------->",this._id,user);
            
let otp=Math.floor(1000 + Math.random() * 7000);
    
const result = await Users.findOne({ email: this.email });
      if (!result) {
         return res.json({status:false,message:"USer Not Found"})
       
     }
       const otpExpire = new Date().getTime();
       console.log('send otp, otp expire time',otpExpire);
       await Users.updateOne({ _id: result._id }, { otp: otp, otpExpire: otpExpire })
  

var mailOptions = {
    to: this.email,
    subject: "Otp for registration is: ",
    html: "<h3>OTP for account verification is </h3>" + "<h1 style='font-weight:bold;'>" + otp + "</h1>"

  };

  mailer.sendMail(mailOptions); 
})

const Users = mongoose.model('User', UserSchema)
    module.exports=Users
