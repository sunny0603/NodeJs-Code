
exports.passwordValidator = (req, res, next) => {

    const isNonWhiteSpace = /^\S*$/;
    if (!isNonWhiteSpace.test(req.body.password)) {
      return res.json({message:"password must not contain Whitespaces"}) ;
    }
  
    const isContainsUppercase = /^(?=.*[A-Z]).*$/;
    if (!isContainsUppercase.test(req.body.password)) {
      return res.json({message:"password must have at least one Uppercase Character."}) ;
    }
  
    const isContainsLowercase = /^(?=.*[a-z]).*$/;
    if (!isContainsLowercase.test(req.body.password)) {
      return res.json({message:"password must have at least one Lowercase Character"});
    }
  
    const isContainsNumber = /^(?=.*[0-9]).*$/;
    if (!isContainsNumber.test(req.body.password)) {
   
      return  res.json({message:"password must not contain Numeric value"});
    }
  
    const isContainsSymbol =/^(?=.*[~`!@#$%^&*()--+={}\[\]|\\:;"'<>,.?/_₹]).*$/;
    if (!isContainsSymbol.test(req.body.password)) {
      return res.json({message:"password must not contain special symbol"}) 
    }
    const isValidLength = /^.{6,10}$/;
    if (!isValidLength.test(req.body.password)) {
      return res.json({message:"password must be 6-10 Characters "}) 
    }
    next();
    
  }
  exports.emailValidate=(req,res,next)=>{
    const isEmail=/([a-zA-Z0-9]+)([\_\.\-{1}])?([a-zA-Z0-9]+)\@([a-zA-Z0-9]+)([\.])([a-zA-Z\.]+)/g;
    if(!isEmail.test(req.body.email)){
      return res.json({message:"email must contains @ and please fill correct email "})
    }else
    {
      next();
    }


  }
 

