
const responseMessage = (response) => {
    return response.json({
       'ALREADY_SEND_OTP':"otp is already send",
    'EMAIL_ALREADY_SEND_':"Email already used please register another email",
     "USER_NOT_VERIFY":"please  first verify this user"
    })
}


module.exports = { responseMessage }