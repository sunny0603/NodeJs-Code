
const nodemailer = require("nodemailer");
const createError = require('http-errors');
const { ResponseCodes } = require('../response-codes/codes');

require('dotenv').config();

var smtpTransport = nodemailer.createTransport({
  host: "smtp-mail.outlook.com", // hostname
  secureConnection: false, // TLS requires secureConnection to be false
  port: 587, // port for secure SMTP
  tls: {
     ciphers:'SSLv3'
  },
  auth: {

    
      user: 'aaaaabbbbbb07@outlook.com',
      pass: 'abc@1996'
  }
});
   
exports.sendMail = (mailOptions)=>{
  mailOptions.from = "aaaaabbbbbb07@outlook.com"
  smtpTransport.sendMail(mailOptions,function(error,info,req,res){
    if(error){
      console.log(error)
      return  res.json({status:false,message:"mail not send"}) 
    } else{
      console.log("OTP has been sent on your registered email");
      return res.json({status:true,message:"OTP has been sent on your registered email"
    })
    }
  })
}