const responseHandler = (response, status, code, message, data) => {
    return response.json({
        status: status ||  false,
        code:code,
        message: message,
        data: data || {}
    })
}

module.exports = responseHandler;