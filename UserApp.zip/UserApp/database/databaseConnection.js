// const mongoose = require('mongoose');

// /// DB Connectivity

// const init = ()=>{
//     mongoose
//         .connect("mongodb://localhost:27017/userdb", {

//             // useNewUrlParser: true,
//             // useUnifiedTopology: true,
//             // useFindAndModify: false,
//             // useCreateIndex: true,
//             // useNewUrlParser: true,
//         })
//         .then(() => {
//             console.log(`DB Connected Successfully.`);
//         })
//         .catch((err) => {
//             console.log(`DB Connectivity Failed !`, err);
//         });
// }

//  module.exports = {init};
// const mongoose = require('mongoose');
// //require('dotenv').config();

// //const url=process.env.Mongo_URL;
// mongoose.connect('mongodb://localhost:27017/userdb', {
//   useNewUrlParser: "true",
//   useUnifiedTopology: "true"
// })
// mongoose.connection.on("error", err => {
//   console.log("err", err)
// })
// mongoose.connection.once("open", (err, res) => {
//   console.log("mongoose Db is connected")
  
// })
// module.exports=mongoose.model;




// const MongoClient = require('mongodb').MongoClient;


// // Connection URL
// const url = 'mongodb://localhost:27017/userdb';

// // Database Name


// // Use connect method to connect to the server
// MongoClient.connect(url, ()=> {

//   console.log("database Connected successfully to server");


// });
// module.exports=MongoClient;

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/userdb');
 
var db = mongoose.connection;
 
db.on('error', console.error.bind(console, 'connection error:'));
 
db.once('open', function() {
  console.log("Connection Successful!");
});
