const express = require('express');
const createError = require('http-errors');
const router = express.Router();
const userController=require('../controller/userController')
const userValidator = require('../utils/validation/userValidation')


router.get('/', function(req, res, next) {
  res.send('UserApp Server is working...')
});
router.post('/registerUser',userValidator.emailValidate,userValidator.passwordValidator,userController.registerUser)
router.post('/verifyOTP',userController.verifyOTP)
router.post('/login',userController.login)
router.post('/reSendOTP',userController.reSendOTP)
router.use(function (req, res, next) {
 // next(createError(404));
});

module.exports = router;